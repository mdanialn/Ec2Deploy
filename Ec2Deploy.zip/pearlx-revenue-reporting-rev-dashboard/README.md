# pearlx-revenue-reporting
* Repo for storing scripts for the purpose of tracking metrics relating to revenue


* subscriber-DB-creds.txt
{
  "host":""
  "dbname":""
  "user":""
  "password":""
}

* PearlXFlex-creds.txt
{
  "email":""
  "password":""
}

* Enphase-creds.json
{
    "User Name":
        {
            "user" : "",
            "password": "",
            "api_key": ""
        }
}

* Enphase-creds.txt
{
  "email":""
  "password":""
}
